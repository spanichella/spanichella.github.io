Development Emails Content Analyzer
Version 1.0

This program is a free software you can redistribute it under the terms of the GNU Public License
as published by the Free Software Fundation either version 2 of the License, or (at your option)
any later version.

Please extract the contents of DECA_API.zip file in a folder of your choice.

The tool uses the version 1.1.0 of the Stanford CoreNLP library available at the following link:
http://nlp.stanford.edu/software/corenlp.shtml

You can find the needed jar files for running the tool in the /lib folder contained in this zip file

Please add the content of the /lib folder and DECA_API.jar to the classpath in 
your java projects before using the DECA API.




