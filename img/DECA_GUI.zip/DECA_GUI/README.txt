Development Emails Content Analyzer
Version 1.0

This program is a free software you can redistribute it under the terms of the GNU Public License
as published by the Free Software Fundation either version 2 of the License, or (at your option)
any later version.

Please extract the contents of DECA_GUI.zip file in a folder of your choice.

The tool uses the version 1.1.0 of the Stanford CoreNLP library available at the following link:
http://nlp.stanford.edu/software/corenlp.shtml

You can find the needed jar files for running the tool in the /lib folder contained in this zip file

Please add these jars and DECA_GUI.jar to the java classpath
and run the org.deca.ui.Main class.

Here we provide a running example from command Line:

running example for Windows Systems:
java -classpath "[MYPATH]/lib/*;[MYPATH]/DECA_GUI.jar" org.deca.ui.Main

running example for Unix/Linux/MacOS Systems:
java -classpath "[MYPATH]/lib/*:[MYPATH]/DECA_GUI.jar" org.deca.ui.Main

Where [MYPATH] is the path in which the contents of the zipped file has been extracted.

